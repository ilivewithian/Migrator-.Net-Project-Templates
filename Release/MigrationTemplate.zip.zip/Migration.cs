﻿using System.Data;
using Migrator.Framework;

namespace $rootnamespace$
{
	[Migration($migrationId$)]
    public class $safeitemname$ : Migration
    {
		public override void Up()
        {
            throw new System.NotImplementedException();
        }

        public override void Down()
        {
            throw new System.NotImplementedException();
        }        
    }
}